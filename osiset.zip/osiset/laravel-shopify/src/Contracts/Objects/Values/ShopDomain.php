<?php

namespace Osiset\ShopifyApp\Contracts\Objects\Values;

use Funeralzone\ValueObjects\ValueObject;

/**
 * Shop domain's value object.
 */
interface ShopDomain extends ValueObject
{
}
