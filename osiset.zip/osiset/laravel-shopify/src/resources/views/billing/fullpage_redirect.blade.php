<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <base target="_top">

        <title>Redirecting...</title>

        <script type="text/javascript">window.top.location.href = "{!! $url !!}";</script>


{{--        <script type="text/javascript">--}}
{{--         var Iframe=   window.frames.getElementsByName('app-iframe');--}}
{{--         const iWindow = Iframe.contentWindow;--}}
{{--         console.log('Iframe',iWindow);--}}
{{--         Iframe.setAttribute("sandbox","allow-top-navigation");--}}
{{--            window.top.location.href = "{!! $url !!}";--}}
{{--        </script>--}}
    </head>
    <body>
{{--    <a href="{!! $url !!}" target="_top"></a>--}}
    </body>
</html>
